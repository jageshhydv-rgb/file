document.addEventListener("click", async e => {
  const b = e.target.closest("[data-link]");
  if (!b) return;
  const url = new URL(b.dataset.link, location.origin).href;
  try {
    await navigator.clipboard.writeText(url);
    b.textContent = "Copied!";
    setTimeout(() => b.textContent = "Copy", 1400);
  } catch {
    window.prompt("Copy this download link:", url);
  }
});
const form = document.getElementById("upload");
if (form) form.addEventListener("submit", () => {
  const b = document.getElementById("uploadBtn");
  b.textContent = "Uploading…";
  b.disabled = true;
});
