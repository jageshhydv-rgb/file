PROJECTSYNC 2.0 — TEMPORARY ENCRYPTED FILE TRANSFER
====================================================

This version uses Node.js (not PHP).

WHAT IT DOES
- PIN login (default PIN: asdfgg)
- PIN is stored as a scrypt hash, not plain text.
- Login rate limit: 8 failed attempts per IP per 15 minutes (in-memory).
- Random 192-bit download IDs.
- Files encrypted at rest with AES-256-GCM.
- Download links work without a second login; treat them like passwords.
- File is deleted only after the server completes sending the decrypted download.
- If a download is interrupted, the encrypted file is kept so you can retry.
- No 24-hour deletion.

IMPORTANT LIMITATIONS
- No software can honestly be guaranteed "zero bugs" or "no loopholes".
- The default PIN "asdfgg" is short. Change it to a longer passphrase before exposing the site publicly.
- The current login limiter is in-memory and resets on server restart. Add host-level rate limiting / a reverse proxy limit for a public deployment.
- The download link is a bearer secret. Anyone who gets it can download the file before it is consumed.
- "Download complete" means the server successfully sent the response. A browser/device can still fail to save the file after receiving it.
- Files remain until downloaded, but the hosting provider can still erase data, restart the service, suspend it, or run out of disk.
- The encryption key and metadata are kept in storage/.secrets.json and storage/meta. Back up storage/.secrets.json securely. If it is lost, encrypted files cannot be recovered.
- This is encrypted at rest, not end-to-end encryption. The server has the key and can decrypt files to deliver downloads.
- Use HTTPS in production. Set NODE_ENV=production so secure session cookies are enabled.
- No email, Telegram, or external cloud storage is used.

RUN LOCALLY
1. Install Node.js 20 or newer.
2. In this folder run: npm install
3. Run: npm start
4. Open http://localhost:3000

DEPLOYMENT
Deploy as a Node.js web service on a host that supports Node 20+.
Set the start command to: npm start
Set NODE_ENV=production.
Use a persistent disk mounted at this app folder (or change STORE paths in server.js to the mounted disk).
Do not use an ephemeral filesystem if you need files to survive restarts/deploys.
Set the host's upload/body limits high enough for your intended file sizes.
Use HTTPS.
Do not expose the storage folder as a public static directory.

FREE HOSTING NOTE
A free host with ephemeral storage cannot guarantee that files remain until you download them. This app needs a host with persistent disk for the promised behavior. Free persistent storage may be unavailable or heavily limited.

SECURITY
Before public use, replace the default PIN with a long unique passphrase and add a proper persistent rate limiter (e.g. Redis-backed) or host-level rate limiting. Do not share download links. Keep the .secrets file private.
