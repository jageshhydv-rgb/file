const express = require("express");
const session = require("express-session");
const Busboy = require("busboy");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const { pipeline } = require("stream/promises");

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", 1);

const ROOT = __dirname;
const STORE = path.join(ROOT, "storage");
const META = path.join(STORE, "meta");
const BLOBS = path.join(STORE, "blobs");
const SECRETS_FILE = path.join(STORE, ".secrets.json");
const PORT = Number(process.env.PORT || 3000);
const MAX_BYTES = Number(process.env.MAX_FILE_BYTES || 100 * 1024 * 1024);
const MAX_FILES = Number(process.env.MAX_FILES_PER_UPLOAD || 20);

for (const dir of [STORE, META, BLOBS]) fs.mkdirSync(dir, { recursive: true, mode: 0o700 });

function loadSecrets() {
  if (fs.existsSync(SECRETS_FILE)) return JSON.parse(fs.readFileSync(SECRETS_FILE, "utf8"));
  // PIN hash for "asdfgg"; only the hash and salt are stored, never the PIN itself.
  const secretsObj = {
    pinSalt: "9dcb6e8f4f0c3d74eab17ac09bd8c2e1",
    pinHash: "51ac5dede95db67b9e3f7a7be63f3b09aab0815f3508be455f1e3635a51f795a9fd986fc788a6060212c2f2cde7feda60ac92133ed670b7721954b1cbdca80cc",
    encryptionKey: crypto.randomBytes(32).toString("hex"),
    sessionSecret: crypto.randomBytes(48).toString("hex")
  };
  fs.writeFileSync(SECRETS_FILE, JSON.stringify(secretsObj), { mode: 0o600, flag: "wx" });
  return secretsObj;
}
const secretsObj = loadSecrets();
const ENC_KEY = Buffer.from(secretsObj.encryptionKey, "hex");

app.use(express.urlencoded({ extended: false, limit: "16kb" }));
app.use(session({
  name: "ps.sid",
  secret: secretsObj.sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));

// Small in-memory login limiter. For public deployments, also enable host-level rate limiting.
const attempts = new Map();
function clientKey(req) { return req.ip || req.socket.remoteAddress || "unknown"; }
function loginBlocked(req) {
  const v = attempts.get(clientKey(req));
  if (!v || Date.now() - v.start > 15 * 60 * 1000) return false;
  return v.count >= 8;
}
function recordFailure(req) {
  const k = clientKey(req), now = Date.now(), v = attempts.get(k);
  if (!v || now - v.start > 15 * 60 * 1000) attempts.set(k, { start: now, count: 1 });
  else v.count++;
}
function requireAuth(req, res, next) {
  if (!req.session.authenticated) return res.redirect("/");
  next();
}
function csrf(req) {
  if (!req.session.csrf) req.session.csrf = crypto.randomBytes(24).toString("hex");
  return req.session.csrf;
}
function safeEqual(a, b) {
  const x = Buffer.from(String(a || ""));
  const y = Buffer.from(String(b || ""));
  return x.length === y.length && x.length > 0 && crypto.timingSafeEqual(x, y);
}
function checkCsrf(req, res, next) {
  if (!safeEqual(req.body && req.body.csrf, req.session.csrf)) {
    return res.status(403).send("Security check failed. Refresh and try again.");
  }
  next();
}
function esc(s) {
  return String(s).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
function page(title, body) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><title>${esc(title)} · ProjectSync</title><link rel="stylesheet" href="/style.css"></head><body><main class="wrap"><header><div class="brand"><span class="mark">P</span><span>ProjectSync</span></div><span class="tag">PRIVATE TRANSFER</span></header>${body}<footer>Private file transfer · Encrypted at rest</footer></main></body></html>`;
}
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  res.setHeader("Content-Security-Policy", "default-src 'self'; style-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
  next();
});
app.use(express.static(path.join(ROOT, "public"), { index: false, dotfiles: "deny", maxAge: "1h" }));

app.get("/", (req, res) => {
  if (req.session.authenticated) return res.redirect("/dashboard");
  res.send(page("Sign in", `<section class="hero"><p class="eyebrow">YOUR PRIVATE FILE BRIDGE</p><h1>Move files.<br><em>Keep moving.</em></h1><p class="sub">Sign in with your private PIN to send files between your phone and laptop.</p></section><form class="panel narrow" method="post" action="/login"><input type="hidden" name="csrf" value="${csrf(req)}"><label for="pin">Access PIN</label><input id="pin" name="pin" type="password" inputmode="text" autocomplete="current-password" required maxlength="64" placeholder="Enter your PIN"><button>Unlock ProjectSync</button><p class="hint">Your files are encrypted on the server.</p></form>`));
});
app.post("/login", (req, res) => {
  if (!safeEqual(req.body && req.body.csrf, req.session.csrf)) return res.status(403).send("Security check failed. Refresh and try again.");
  if (loginBlocked(req)) return res.status(429).send("Too many attempts. Try again in 15 minutes.");
  const supplied = String(req.body.pin || "");
  const actual = crypto.scryptSync(supplied, secretsObj.pinSalt, 64);
  const expected = Buffer.from(secretsObj.pinHash, "hex");
  if (actual.length === expected.length && crypto.timingSafeEqual(actual, expected)) {
    attempts.delete(clientKey(req));
    req.session.regenerate(err => {
      if (err) return res.status(500).send("Could not create a secure session.");
      req.session.authenticated = true;
      req.session.csrf = crypto.randomBytes(24).toString("hex");
      res.redirect("/dashboard");
    });
  } else {
    recordFailure(req);
    res.status(401).send(page("Try again", `<section class="panel narrow"><h2>PIN not accepted</h2><p class="sub">Check your PIN and try again.</p><a class="button secondary" href="/">Back to sign in</a></section>`));
  }
});
app.get("/dashboard", requireAuth, (req, res) => {
  const files = fs.readdirSync(META).filter(n => n.endsWith(".json")).map(n => {
    try { return JSON.parse(fs.readFileSync(path.join(META, n), "utf8")); } catch { return null; }
  }).filter(Boolean).sort((a,b) => b.created - a.created);
  const rows = files.map(f => `<article class="file"><div class="fileicon">↧</div><div class="fileinfo"><strong>${esc(f.name)}</strong><small>${(f.size/1024/1024).toFixed(2)} MB · Waiting for download</small><a href="/d/${encodeURIComponent(f.id)}">Copy download link</a></div><button class="copy" type="button" data-link="${esc("/d/"+f.id)}">Copy</button></article>`).join("") || `<p class="empty">No files yet. Upload from your phone to get started.</p>`;
  res.send(page("Dashboard", `<section class="hero compact"><p class="eyebrow">PRIVATE WORKSPACE</p><h1>Your files,<br><em>within reach.</em></h1><p class="sub">Upload from your phone, then open the download link on your laptop.</p></section><section class="panel"><h2>Upload files</h2><form id="upload" method="post" action="/upload" enctype="multipart/form-data"><input type="hidden" name="csrf" value="${csrf(req)}"><label class="drop"><span class="uploadicon">＋</span><strong>Choose files</strong><small>Any file type · Up to ${(MAX_BYTES/1024/1024).toFixed(0)} MB per file</small><input type="file" name="files" multiple required></label><button id="uploadBtn">Upload securely</button></form><p id="status" class="hint">Files stay here until a download finishes. No 24-hour deletion.</p></section><section class="panel"><div class="sectionhead"><h2>Waiting for download</h2><span class="count">${files.length}</span></div>${rows}</section><form method="post" action="/logout"><input type="hidden" name="csrf" value="${csrf(req)}"><button class="secondary logout">Lock ProjectSync</button></form><script src="/app.js" defer></script>`));
});
app.post("/logout", requireAuth, checkCsrf, (req, res) => req.session.destroy(() => res.redirect("/")));

app.post("/upload", requireAuth, (req, res) => {
  const bb = Busboy({ headers: req.headers, limits: { files: MAX_FILES, fileSize: MAX_BYTES, fields: 2 } });
  const csrfValue = req.headers["x-csrf-token"];
  // Multipart forms are validated through the hidden field as it is parsed.
  let csrfSeen = false, uploadError = null, pending = [], count = 0;
  bb.on("field", (name, val) => { if (name === "csrf" && safeEqual(val, req.session.csrf)) csrfSeen = true; });
  bb.on("file", (field, stream, info) => {
    if (field !== "files") { stream.resume(); return; }
    count++;
    const id = crypto.randomBytes(24).toString("hex");
    const cleanName = path.basename(String(info.filename || "file").replace(/[\u0000-\u001f\u007f]/g, "")).slice(0, 180) || "file";
    const temp = path.join(BLOBS, id + ".tmp");
    const final = path.join(BLOBS, id + ".enc");
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv("aes-256-gcm", ENC_KEY, iv);
    let size = 0;
    stream.on("data", chunk => { size += chunk.length; });
    const p = pipeline(stream, cipher, fs.createWriteStream(temp, { flags: "wx", mode: 0o600 }))
      .then(() => {
        if (stream.truncated) throw new Error("A file exceeded the upload size limit.");
        const tag = cipher.getAuthTag();
        fs.renameSync(temp, final);
        const meta = { id, name: cleanName, size, created: Date.now(), iv: iv.toString("hex"), tag: tag.toString("hex") };
        fs.writeFileSync(path.join(META, id + ".json"), JSON.stringify(meta), { mode: 0o600, flag: "wx" });
        pending.push({ id, stored: true });
      }).catch(err => {
        uploadError = err.message;
        try { fs.unlinkSync(temp); } catch {}
        try { fs.unlinkSync(final); } catch {}
        try { fs.unlinkSync(path.join(META, id + ".json")); } catch {}
      });
    stream.on("limit", () => { uploadError = "A file exceeded the upload size limit."; });
    pending.push(p);
  });
  bb.on("filesLimit", () => { uploadError = "Too many files in one upload."; });
  bb.on("error", err => { uploadError = err.message; });
  bb.on("finish", async () => {
    await Promise.all(pending.filter(p => p && typeof p.then === "function"));
    if (!csrfSeen) {
      for (const item of pending) if (item && item.stored) {
        try { fs.unlinkSync(path.join(BLOBS, item.id + ".enc")); } catch {}
        try { fs.unlinkSync(path.join(META, item.id + ".json")); } catch {}
      }
      return res.status(403).send("Security check failed. Refresh and try again.");
    }
    if (uploadError) return res.status(400).send("Upload failed: " + esc(uploadError));
    if (!count) return res.status(400).send("Choose at least one file.");
    res.redirect("/dashboard");
  });
  req.pipe(bb);
});

app.get("/d/:id", async (req, res) => {
  const id = String(req.params.id || "");
  if (!/^[a-f0-9]{48}$/.test(id)) return res.status(404).send("Link not found.");
  const mp = path.join(META, id + ".json"), bp = path.join(BLOBS, id + ".enc");
  if (!fs.existsSync(mp) || !fs.existsSync(bp)) return res.status(404).send("This file was already downloaded or does not exist.");
  let meta;
  try { meta = JSON.parse(fs.readFileSync(mp, "utf8")); } catch { return res.status(404).send("File unavailable."); }
  res.setHeader("Content-Type", "application/octet-stream");
  res.setHeader("Content-Disposition", `attachment; filename="download"; filename*=UTF-8''${encodeURIComponent(meta.name)}`);
  res.setHeader("Cache-Control", "no-store, private");
  res.setHeader("Content-Length", String(meta.size));
  const decipher = crypto.createDecipheriv("aes-256-gcm", ENC_KEY, Buffer.from(meta.iv, "hex"));
  decipher.setAuthTag(Buffer.from(meta.tag, "hex"));
  try {
    await pipeline(fs.createReadStream(bp), decipher, res);
    // Delete only after the complete decrypted response has been sent successfully.
    fs.unlinkSync(bp);
    fs.unlinkSync(mp);
  } catch (err) {
    // Keep the encrypted file if the connection breaks or decryption fails, so the user can retry.
    if (!res.headersSent) res.status(500).send("Download interrupted. The file is still available; try again.");
    else res.destroy();
  }
});

app.get("/health", (req, res) => res.status(200).json({ ok: true }));
app.use((err, req, res, next) => { console.error("Request error:", err.message); if (!res.headersSent) res.status(500).send("Something went wrong."); });

app.listen(PORT, "0.0.0.0", () => console.log(`ProjectSync running on port ${PORT}`));
